"""Exercise the real-data archive format and the PyTorch training path."""

from io import BytesIO
from pathlib import Path
import tarfile
import tempfile
import unittest

import numpy as np

try:
    import torch
except ImportError:
    torch = None

if torch is not None:
    from PIL import Image
    from shiftlens.visa import load_archive, load_manifest, score, train_net, fit_template, SIZE


@unittest.skipIf(torch is None, "Install requirements-dl.txt to test the convolutional pipeline.")
class VisaTests(unittest.TestCase):
    def test_archive_records_and_training_forward_pass(self):
        torch.set_num_threads(1)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            manifest = root / "split.csv"
            manifest.write_text("object,split,label,image,mask\n"
                                "pcb1,train,normal,pcb1/Data/Images/Normal/a.JPG,\n"
                                "pcb1,test,anomaly,pcb1/Data/Images/Anomaly/b.JPG,\n", encoding="utf-8")
            path = root / "visa.tar"
            image_bytes = BytesIO()
            Image.fromarray(np.full((50, 50, 3), 75, np.uint8)).save(image_bytes, format="JPEG")
            encoded = image_bytes.getvalue()
            with tarfile.open(path, "w") as archive:
                for which, name in (("Normal", "a"), ("Anomaly", "b")):
                    member = tarfile.TarInfo(f"archive/pcb1/Data/Images/{which}/{name}.JPG")
                    member.size = len(encoded)
                    archive.addfile(member, BytesIO(encoded))
            rows = load_archive(path, load_manifest(manifest), root / "cache")["pcb1"]
            self.assertEqual([row[2] for row in rows], [False, True])
            image = np.load(rows[0][3], allow_pickle=False)
            self.assertEqual(image.shape, (SIZE, SIZE, 3))
            images = np.stack((image, image))
            model = train_net(images, "cpu", 1, 2, 42, lambda *_: None)
            predictions, maps = score(rows, images, model, fit_template(images), "cpu", 2)
            self.assertEqual(len(predictions), 2)
            self.assertEqual(len(maps), 2)
            self.assertTrue(all(np.isfinite(p.scores["Convolutional detector"]) for p in predictions))

    def test_rejects_duplicate_or_out_of_scope_records(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "invalid.csv"
            path.write_text("object,split,label,image,mask\n"
                            "pcb1,train,normal,pcb1/../private.JPG,\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Invalid"):
                load_manifest(path)
