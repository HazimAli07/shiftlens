from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

import numpy as np

from shiftlens.dataset import View, load_realiad, partition
from shiftlens.evaluate import Prediction, summarize, threshold_for_fpr
from shiftlens.model import patchify


def part(part_id, defect=False):
    return [View(part_id, camera, Path("unused"), defect) for camera in range(1, 6)]


class DatasetTests(unittest.TestCase):
    def test_split_keeps_complete_parts_together(self):
        train = [view for index in range(10) for view in part(f"train-{index}")]
        fit, calibration, test, dropped = partition(train, part("test") + part("partial")[:-1], 42)
        self.assertEqual(len(fit), 40)
        self.assertEqual(len(calibration), 2)
        self.assertEqual(set(test), {"test"})
        self.assertEqual(dropped["incomplete_test"], 1)
        self.assertFalse({view.part for view in fit} & calibration.keys())

    def test_overlap_is_rejected(self):
        train = [view for index in range(5) for view in part(f"part-{index}")]
        with self.assertRaisesRegex(ValueError, "both train and test"):
            partition(train, part("part-1"), 42)

    def test_duplicate_camera_is_rejected(self):
        train = [view for index in range(5) for view in part(f"part-{index}")]
        with self.assertRaisesRegex(ValueError, "repeated camera"):
            partition(train + [train[0]], part("test"), 42)

    def test_realiad_metadata_adapter(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "realiad_jsons").mkdir()
            rows = {}
            for split_name, part_id, label in (("train", "0001", "OK"), ("test", "0002", "NG")):
                rows[split_name] = []
                for camera in range(1, 6):
                    relative = Path(label) / f"S{part_id}" / f"audiojack_{part_id}_{label}_C{camera}_001.jpg"
                    fullpath = root / "realiad_1024" / "audiojack" / relative
                    fullpath.parent.mkdir(parents=True, exist_ok=True)
                    fullpath.touch()
                    rows[split_name].append({"image_path": str(relative), "anomaly_class": label})
            metadata = root / "realiad_jsons" / "audiojack.json"
            metadata.write_text(json.dumps(rows), encoding="utf-8")
            train, test = load_realiad(root, "audiojack")
            self.assertEqual({view.part for view in train}, {"audiojack_0001_OK"})
            self.assertEqual([view.camera for view in test], list(range(1, 6)))
            self.assertTrue(all(view.defect for view in test))
            rows["train"][0]["image_path"] = "../outside.jpg"
            metadata.write_text(json.dumps(rows), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "leaves category"):
                load_realiad(root, "audiojack")


class ModelTests(unittest.TestCase):
    def test_patchify_preserves_local_positions(self):
        image = np.zeros((16, 16, 3), dtype=np.uint8)
        image[:8, 8:] = 255
        patches, grid = patchify(image, 8)
        self.assertEqual(grid, (2, 2))
        np.testing.assert_equal(patches.mean(axis=1), [0, 1, 0, 0])

    def test_calibration_budget_and_ties(self):
        scores = [0.1, 0.2, 0.7, 0.7, 0.9]
        threshold = threshold_for_fpr(scores, 0.2)
        self.assertEqual(threshold, 0.7)
        self.assertEqual(sum(score > threshold for score in scores), 1)

    def test_metrics_use_unseen_part_labels(self):
        calibration = [Prediction("calibration", False, {"network-multi": 0.3})]
        test = [Prediction("defect", True, {"network-multi": 0.8}),
                Prediction("normal", False, {"network-multi": 0.2}),
                Prediction("false_alarm", False, {"network-multi": 0.4})]
        result = summarize(calibration, test, 0.05)["network-multi"]
        self.assertEqual(result["recall"], 1)
        self.assertEqual(result["false_rejects_per_1000"], 500)

    def test_training_writes_model_and_report(self):
        with tempfile.TemporaryDirectory() as folder:
            result = subprocess.run(
                [sys.executable, "-m", "shiftlens", "--fixture", "--epochs", "1", "--out", folder],
                text=True, capture_output=True, check=True,
            )
            self.assertIn("Epoch 1/1", result.stdout)
            report = json.loads((Path(folder) / "report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["dataset"], "Synthetic fixture")
            self.assertEqual(len(report["metrics"]), 4)
            self.assertEqual(report["test_parts"], 36)
            with np.load(Path(folder) / "network.npz", allow_pickle=False) as weights:
                self.assertEqual(weights["weight_0"].shape, (192, 64))
            html = (Path(folder) / "index.html").read_text(encoding="utf-8")
            self.assertIn("data:image/png;base64,", html)


if __name__ == "__main__":
    unittest.main()
