"""Build a standalone app for GitHub Pages and offline use."""

import argparse
from base64 import b64encode
import json
import mimetypes
from pathlib import Path


def data_uri(path):
    mime, _ = mimetypes.guess_type(path.name)
    return f"data:{mime};base64,{b64encode(path.read_bytes()).decode()}"


def payload(path):
    return path.read_text().split("=", 1)[1].rstrip(";\n")


def build(generated, target):
    page = (generated / "index.html").read_text()
    assets = generated / "assets"
    report = json.loads((assets / "benchmark.json").read_text())
    models = []
    for category in report["categories"]:
        name = category["category"]
        models.append(f'<script type="application/json" id="model-{name}">{payload(assets / (name + ".js"))}</script>')
        for item in category["examples"]:
            item["path"] = data_uri(generated / item["path"])
    data = json.dumps(report, separators=(",", ":"), allow_nan=False).replace("<", "\\u003c")
    style = (generated / "style.css").read_text()
    script = (generated / "app.js").read_text()
    segment = """      const embedded = document.getElementById("model-" + key);
      if (embedded) {
        try {
          const model = JSON.parse(embedded.textContent);
          model.layers = model.layers.map(layer => ({...layer, w: unpack(layer.w), b: unpack(layer.b)}));
          model.mean = unpack(model.mean);
          model.scale = unpack(model.scale);
          resolve(model);
        } catch (error) { reject(error); }
        return;
      }
"""
    marker = '      const script = document.createElement("script");'
    if script.count(marker) != 1:
        raise ValueError("Could not find the category model loader.")
    script = script.replace(marker, segment + marker)
    page = page.replace('<link rel="stylesheet" href="style.css">', f"<style>{style}</style>")
    page = page.replace('<script src="assets/benchmark.js" defer></script>', "")
    page = page.replace('<script src="app.js" defer></script>', "")
    page = page.replace('src="assets/inspection.jpg"', f'src="{data_uri(assets / "inspection.jpg")}"')
    page = page.replace("</body>", "\n".join(models) + f"<script>window.shiftData={data};</script><script>{script}</script></body>")
    if 'src="assets/' in page or len(models) != 12:
        raise ValueError("Standalone release is missing a required asset.")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding="utf-8")


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--generated", type=Path, default=Path("docs"))
    args.add_argument("--output", type=Path, required=True)
    params = args.parse_args()
    build(params.generated, params.output)
