"use strict";
const unpack = (text) => {
  const bytes = Uint8Array.from(atob(text), c => c.charCodeAt(0));
  const data = new DataView(bytes.buffer);
  return Float32Array.from({length:bytes.length/4}, (_,i) => data.getFloat32(i*4,true));
};
function gelu(x) {
  const sign = x < 0 ? -1 : 1;
  const y = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + 0.3275911 * y);
  const erf = 1 - (((((1.061405429*t - 1.453152027)*t + 1.421413741)*t - 0.284496736)
    *t + 0.254829592)*t)*Math.exp(-y*y);
  return 0.5*x*(1+sign*erf);
}
function convolution(input, side, layer) {
  const {cin,cout,k,s,p,w,b,activate} = layer;
  const n = Math.floor((side + 2*p - k)/s)+1;
  const output = new Float32Array(cout*n*n);
  for (let c=0;c<cout;c++) for (let oy=0;oy<n;oy++) for(let ox=0;ox<n;ox++) {
    let sum=b[c];
    for(let d=0;d<cin;d++) for(let ky=0;ky<k;ky++) {
      const iy=oy*s+ky-p;
      if(iy<0 || iy>=side) continue;
      for(let kx=0;kx<k;kx++) {
        const ix=ox*s+kx-p;
        if(ix<0 || ix>=side) continue;
        sum += input[(d*side+iy)*side+ix]*w[((c*cin+d)*k+ky)*k+kx];
      }
    }
    output[(c*n+oy)*n+ox]=activate ? gelu(sum) : sum;
  }
  return [output,n];
}
const CNN = "Convolutional detector";
const TEMPLATE = "Reference template";
const RETRIEVAL = "Patch retrieval";
const MODEL_TITLE = { [CNN]: "CNN", [TEMPLATE]: "Reference template", [RETRIEVAL]: "Patch retrieval" };
const LABELS = { candle: "Candle", capsules: "Capsules", cashew: "Cashew", chewinggum: "Chewing gum", fryum: "Fryum", macaroni1: "Macaroni 1", macaroni2: "Macaroni 2", pcb1: "PCB 1", pcb2: "PCB 2", pcb3: "PCB 3", pcb4: "PCB 4", pipe_fryum: "Pipe fryum" };
const $ = id => document.getElementById(id);
const categories = window.shiftData.categories;
const categoryControl = $("category");
const statusBox = $("inspect-status");
const originals = $("original").getContext("2d", {willReadFrequently: true});
const heatContext = $("heat").getContext("2d");
const session = [];
let selected = null;
let view = TEMPLATE;
let working = false;
window.shiftModels = Object.create(null);
const loads = new Map();

for (const row of categories) {
  for (const target of [categoryControl, $("result-category")]) {
    const option = document.createElement("option");
    option.value = row.category;
    option.textContent = LABELS[row.category] || row.category;
    target.append(option);
  }
}
categoryControl.value = "pcb1";

function modelFor(key) {
  if (!loads.has(key)) {
    const task = new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "assets/" + key + ".js";
      script.onload = () => {
        const model = window.shiftModels[key];
        if (!model) { reject(new Error("This category model is unavailable.")); return; }
        model.layers = model.layers.map(layer => ({...layer, w: unpack(layer.w), b: unpack(layer.b)}));
        model.mean = unpack(model.mean);
        model.scale = unpack(model.scale);
        resolve(model);
      };
      script.onerror = () => reject(new Error("The category model could not be loaded."));
      document.head.append(script);
    });
    loads.set(key, task);
    task.catch(() => loads.delete(key));
  }
  return loads.get(key);
}

function topTwo(scores) {
  let first = -Infinity, second = -Infinity;
  for (const score of scores) {
    if (score > first) { second = first; first = score; }
    else if (score > second) second = score;
  }
  return (first + second) / 2;
}

function calculate(image, model) {
  const side = 128;
  const source = image.data;
  let input = new Float32Array(3 * side * side);
  for (let pixel = 0; pixel < side * side; pixel++)
    for (let channel = 0; channel < 3; channel++)
      input[channel * side * side + pixel] = source[pixel * 4 + channel] / 255;
  let width = side;
  for (const layer of model.layers) [input, width] = convolution(input, width, layer);
  const cnn = Float32Array.from(input, value => 1 / (1 + Math.exp(-value)));
  const template = new Float32Array(256);
  for (let py = 0; py < 16; py++) for (let px = 0; px < 16; px++) {
    const patch = py * 16 + px;
    let sum = 0, channelIndex = patch * 192;
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
      const pixel = ((py * 8 + y) * side + px * 8 + x) * 4;
      for (let color = 0; color < 3; color++, channelIndex++)
        sum += Math.abs(source[pixel + color] / 255 - model.mean[channelIndex]) / model.scale[channelIndex];
    }
    template[patch] = sum / 192;
  }
  const output = {};
  for (const [name, map] of [[CNN, cnn], [TEMPLATE, template]]) {
    const cutoff = model.thresholds[name], score = topTwo(map);
    output[name] = {score, cutoff, flagged: score > cutoff, map};
  }
  return output;
}

function verdict(result) { return result.flagged ? "Review" : "Below cutoff"; }

function setView(mode) {
  view = mode;
  for (const [name, button] of [[CNN, $("view-cnn")], [TEMPLATE, $("view-template")]]) {
    button.classList.toggle("selected", name === view);
    button.setAttribute("aria-pressed", String(name === view));
  }
  if (selected) showHeatmap();
}

function showHeatmap() {
  const result = selected.output[view];
  const pixels = new Uint8ClampedArray(selected.pixels.data);
  for (let y = 0; y < 128; y++) for (let x = 0; x < 128; x++) {
    const position = Math.floor(y / 8) * 16 + Math.floor(x / 8);
    const alpha = Math.min(.76, Math.max(0, (result.map[position] / Math.max(result.cutoff, .0001) - .38) * .63));
    const index = (y * 128 + x) * 4;
    pixels[index] = pixels[index] * (1-alpha) + 253*alpha;
    pixels[index+1] = pixels[index+1] * (1-alpha) + 103*alpha;
    pixels[index+2] = pixels[index+2] * (1-alpha) + 63*alpha;
  }
  heatContext.putImageData(new ImageData(pixels, 128, 128), 0, 0);
}

function display(item) {
  selected = item;
  originals.putImageData(item.pixels, 0, 0);
  showHeatmap();
  const boxes = [TEMPLATE, CNN].map(name => {
    const r = item.output[name];
    const box = document.createElement("div");
    box.className = "score " + (r.flagged ? "flag" : "clear");
    const title = document.createElement("strong");
    title.textContent = MODEL_TITLE[name] + " · " + verdict(r);
    const numbers = document.createElement("small");
    numbers.textContent = r.score.toFixed(5) + " score · " + r.cutoff.toFixed(5) + " cutoff";
    box.append(title, numbers);
    return box;
  });
  $("scores").replaceChildren(...boxes);
}

function addHistory(item) {
  const row = document.createElement("tr");
  const button = document.createElement("button");
  button.type = "button";
  button.className = "result-button";
  button.textContent = item.name;
  button.addEventListener("click", () => { display(item); statusBox.textContent = item.name; });
  row.insertCell().append(button);
  row.insertCell().textContent = LABELS[item.category] || item.category;
  for (const model of [TEMPLATE, CNN]) {
    const td = row.insertCell();
    td.textContent = verdict(item.output[model]);
    td.className = item.output[model].flagged ? "flag" : "clear";
  }
  if (!session.length) $("history").replaceChildren();
  session.push(item);
  $("history").prepend(row);
  $("export").disabled = false;
}

async function evaluate(items) {
  if (working) return;
  working = true;
  const key = categoryControl.value;
  const controls = [categoryControl, $("sample-normal"), $("sample-defect"), $("upload")];
  controls.forEach(element => { element.disabled = true; });
  const failed = [];
  try {
    statusBox.textContent = "Preparing " + (LABELS[key] || key) + " detectors…";
    const model = await modelFor(key);
    for (const item of items) {
      try {
        statusBox.textContent = "Inspecting " + item.name + "…";
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const image = await item.load();
        try {
          originals.fillStyle = "#ffffff";
          originals.fillRect(0, 0, 128, 128);
          originals.drawImage(image, 0, 0, 128, 128);
        } finally { if (typeof image.close === "function") image.close(); }
        const pixels = originals.getImageData(0, 0, 128, 128);
        const result = {name: item.name, category: key, pixels, output: calculate(pixels, model)};
        addHistory(result);
        display(result);
        if (item.expected) {
          const tolerance = Math.max(...[CNN, TEMPLATE].map(name => Math.abs(result.output[name].score - item.expected[name])));
          statusBox.textContent = "Held-out " + item.kind + " image · maximum difference from Python " + tolerance.toExponential(2);
          statusBox.dataset.parity = String(tolerance);
        } else {
          delete statusBox.dataset.parity;
          statusBox.textContent = item.name + " inspected.";
        }
      } catch (error) { failed.push(item.name + ": " + error.message); }
    }
    if (failed.length) statusBox.textContent = failed.join(" · ");
  } catch (error) { statusBox.textContent = error.message; }
  finally { controls.forEach(element => { element.disabled = false; }); working = false; }
}

function sample(kind) {
  const row = categories.find(entry => entry.category === categoryControl.value);
  const example = row.examples.find(entry => entry.kind === kind);
  evaluate([{name: kind === "defect" ? "Held-out defect" : "Held-out normal", kind,
    expected: example.scores, load: () => new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("Example image could not be opened."));
      image.src = example.path;
    })}]);
}

$("sample-normal").addEventListener("click", () => sample("normal"));
$("sample-defect").addEventListener("click", () => sample("defect"));
$("view-template").addEventListener("click", () => setView(TEMPLATE));
$("view-cnn").addEventListener("click", () => setView(CNN));
$("upload").addEventListener("change", event => {
  const files = Array.from(event.target.files);
  event.target.value = "";
  if (files.length > 24) { statusBox.textContent = "Choose up to 24 images per batch."; return; }
  if (!files.length) return;
  evaluate(files.map(file => ({name: file.name, load: async () => {
    if (file.size > 15 * 1024 * 1024) throw new Error("Choose an image no larger than 15 MB.");
    if (!/\.(png|jpe?g|webp)$/i.test(file.name)) throw new Error("Use a JPG, PNG, or WebP image.");
    return createImageBitmap(file);
  }})));
});

function cell(value) {
  const text = String(value);
  const safe = /^\s*[=+\-@]/.test(text) ? "'" + text : text;
  return '"' + safe.replaceAll('"', '""') + '"';
}

$("export").addEventListener("click", () => {
  const rows = [["Image", "Category", "Model", "Score", "Cutoff", "Decision"]];
  for (const item of session) for (const detector of [TEMPLATE, CNN]) {
    const metrics = item.output[detector];
    rows.push([item.name, item.category, detector, metrics.score.toFixed(9), metrics.cutoff.toFixed(9), verdict(metrics)]);
  }
  const blob = new Blob([rows.map(row => row.map(cell).join(",")).join("\r\n")], {type: "text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "shiftlens-inspection.csv"; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

function benchmark() {
  const match = $("result-category").value;
  const rows = categories.filter(row => !match || row.category === match);
  const detectors = [TEMPLATE, CNN, RETRIEVAL].filter(name => rows.every(row => row.metrics[name]));
  const cards = detectors.map(detector => {
    const fields = rows.map(row => row.metrics[detector]);
    const total = key => fields.reduce((sum, row) => sum + row[key], 0);
    const card = document.createElement("div");
    card.className = "bench-card";
    const label = document.createElement("strong");
    label.textContent = MODEL_TITLE[detector];
    const primary = document.createElement("b");
    primary.textContent = total("true_rejects").toLocaleString() + " / " + total("defective_test_parts").toLocaleString();
    const caption = document.createElement("span");
    caption.textContent = "defects caught";
    const secondary = document.createElement("small");
    secondary.textContent = total("false_rejects") + " of " + total("normal_test_parts").toLocaleString() + " good images flagged";
    card.append(label, primary, caption, secondary);
    return card;
  });
  $("bench-cards").replaceChildren(...cards);
  const table = [];
  for (const row of rows) for (const detector of detectors) {
    const m = row.metrics[detector], tr = document.createElement("tr");
    for (const value of [LABELS[row.category] || row.category, MODEL_TITLE[detector], m.true_rejects + " / " + m.defective_test_parts, m.false_rejects + " / " + m.normal_test_parts, m.auroc.toFixed(3)])
      tr.insertCell().textContent = value;
    table.push(tr);
  }
  $("benchmark-body").replaceChildren(...table);
}

$("result-category").addEventListener("change", benchmark);
benchmark();
sample("defect");
