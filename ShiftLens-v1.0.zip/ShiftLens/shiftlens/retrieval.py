"""Benchmark a location-aware nearest-neighbor detector on the original VisA split."""

import argparse
from base64 import b64encode
from collections import defaultdict
import hashlib
import json
from pathlib import Path

import numpy as np

from .evaluate import Prediction, summarize
from .visa import PATCH, SIZE, load_images, load_manifest, split_category

METHOD = "Patch retrieval"
REFERENCE_IMAGES = 64


def descriptors(images):
    """Summarize color variation and horizontal/vertical contrast in each patch."""
    size = images.shape[1]
    grid = size // PATCH
    pixels = images.astype(np.float32) / 255
    blocks = pixels.reshape(len(pixels), grid, PATCH, grid, PATCH, 3).transpose(0, 1, 3, 2, 4, 5)
    means = blocks.mean(axis=(3, 4))
    std = blocks.std(axis=(3, 4))
    dx = np.abs(np.diff(blocks, axis=4)).mean(axis=(3, 4))
    dy = np.abs(np.diff(blocks, axis=3)).mean(axis=(3, 4))
    return np.concatenate((means, std, dx, dy), axis=-1).reshape(len(images), grid * grid, 12)


def fit_retrieval(features, seed):
    rng = np.random.default_rng(seed)
    center = features.mean(axis=0)
    scale = np.maximum(features.std(axis=0), 0.025)
    indices = rng.choice(len(features), min(REFERENCE_IMAGES, len(features)), replace=False)
    bank = ((features[indices] - center) / scale).transpose(1, 0, 2).copy()
    return center, scale, bank


def patch_distances(features, model):
    center, scale, bank = model
    normalized = ((features - center) / scale).transpose(1, 0, 2)
    similarities = normalized @ bank.transpose(0, 2, 1)
    squared = (normalized ** 2).sum(axis=2)[:, :, None] + (bank ** 2).sum(axis=2)[:, None, :] - 2 * similarities
    return np.sqrt(np.maximum(squared.min(axis=2), 0) / normalized.shape[2]).T


def score_retrieval(rows, images, model):
    predictions = []
    for start in range(0, len(rows), 24):
        maps = patch_distances(descriptors(images[start:start + 24]), model)
        scores = np.partition(maps, -2, axis=1)[:, -2:].mean(axis=1)
        for record, score_value in zip(rows[start:start + 24], scores, strict=True):
            predictions.append(Prediction(record[0], record[2], {METHOD: float(score_value)}))
    return predictions


def cache_rows(run, manifest):
    records = defaultdict(list)
    for key, (category, split, defective) in load_manifest(manifest).items():
        name = hashlib.sha256(key.encode()).hexdigest()
        path = run / "cache" / category / f"{name}.npy"
        records[category].append((key, split, defective, path))
    return records


def evaluate_retrieval(run, manifest):
    report = json.loads((run / "report.json").read_text())
    rows = cache_rows(run, manifest)
    categories = {}
    for expected in report["categories"]:
        category = expected["category"]
        fit, calibration, test = split_category(rows[category], report["seed"])
        if [len(fit), len(calibration), len(test)] != [expected["train"], expected["calibration"], expected["test"]]:
            raise ValueError(f"Split differs from reference run for {category}")
        features = np.concatenate([descriptors(load_images(fit[i:i + 32])) for i in range(0, len(fit), 32)])
        model = fit_retrieval(features, report["seed"])
        normal = score_retrieval(calibration, load_images(calibration), model)
        predictions = score_retrieval(test, load_images(test), model)
        categories[category] = summarize(normal, predictions, report["calibration_fpr"])[METHOD]
        print(f"{category} {categories[category]['auroc']:.3f}", flush=True)
    target = run / "retrieval.json"
    target.write_text(json.dumps({"method": METHOD, "reference_images": REFERENCE_IMAGES,
                                  "categories": categories}, indent=2, allow_nan=False) + "\n")
    return categories


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    args = parser.parse_args()
    evaluate_retrieval(args.run, args.manifest)
