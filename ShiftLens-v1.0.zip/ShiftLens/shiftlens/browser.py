"""Export the fitted PCB1 detector as a self-contained browser demo."""

import argparse
from base64 import b64encode
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn

from .report import png_data
from .visa import METHODS, PatchNet, load_manifest

SECTION = """
<section class="panel" id="browser-demo">
<h2>Run the PCB1 model in Chrome</h2>
<p>Choose a real held-out example or a local image of a similar board. The detector runs in this tab and uses the PCB1 calibration threshold.</p>
<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
  <button type="button" id="visa-example">Run a held-out defect</button>
  <label>Choose a local image <input type="file" id="visa-input" accept="image/*"></label>
</div>
<p id="visa-result" role="status">Ready to inspect an image.</p>
<canvas id="visa-heatmap" width="128" height="128" aria-label="Input image with model heatmap"
  style="display:block;width:min(100%,320px);height:auto;border-radius:7px;background:#0e1218"></canvas>
</section>
"""

SCRIPT = """
const model = JSON.parse(document.getElementById('visa-weights').textContent);
const status = document.getElementById('visa-result');
const view = document.getElementById('visa-heatmap');
const ctx = view.getContext('2d', {willReadFrequently:true});
const unpack = (text) => {
  const bytes = Uint8Array.from(atob(text), c => c.charCodeAt(0));
  const data = new DataView(bytes.buffer);
  return Float32Array.from({length:bytes.length/4}, (_,i) => data.getFloat32(i*4,true));
};
for (const layer of model.layers) {
  layer.w = unpack(layer.w);
  layer.b = unpack(layer.b);
}
function gelu(x) {
  const sign = x < 0 ? -1 : 1;
  const y = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + 0.3275911 * y);
  const erf = 1 - (((((1.061405429*t - 1.453152027)*t + 1.421413741)*t - 0.284496736)
    *t + 0.254829592)*t)*Math.exp(-y*y);
  return 0.5*x*(1+sign*erf);
}
function convolution(input, side, layer) {
  const {cin,cout,k,s,p,w,b,activate} = layer;
  const n = Math.floor((side + 2*p - k)/s)+1;
  const output = new Float32Array(cout*n*n);
  for (let c=0;c<cout;c++) for (let oy=0;oy<n;oy++) for(let ox=0;ox<n;ox++) {
    let sum=b[c];
    for(let d=0;d<cin;d++) for(let ky=0;ky<k;ky++) {
      const iy=oy*s+ky-p;
      if(iy<0 || iy>=side) continue;
      for(let kx=0;kx<k;kx++) {
        const ix=ox*s+kx-p;
        if(ix<0 || ix>=side) continue;
        sum += input[(d*side+iy)*side+ix]*w[((c*cin+d)*k+ky)*k+kx];
      }
    }
    output[(c*n+oy)*n+ox]=activate ? gelu(sum) : sum;
  }
  return [output,n];
}
function inspect(image, knownScore) {
  const side=128, pixels=side*side;
  ctx.drawImage(image,0,0,side,side);
  const rgba = ctx.getImageData(0,0,side,side);
  let input = new Float32Array(3*pixels);
  for(let c=0;c<3;c++) for(let i=0;i<pixels;i++) input[c*pixels+i]=rgba.data[4*i+c]/255;
  let width=side;
  for(const layer of model.layers) [input,width]=convolution(input,width,layer);
  const scores=Float32Array.from(input, x => 1/(1+Math.exp(-x)));
  const sorted=Array.from(scores).sort((a,b)=>b-a);
  const score=(sorted[0]+sorted[1])/2;
  for (let y=0;y<side;y++) for(let x=0;x<side;x++) {
    const i=(y*side+x)*4;
    const heat=Math.max(0,Math.min(0.72,(scores[Math.floor(y/8)*width+Math.floor(x/8)]-0.1)*0.9));
    for(let c=0;c<3;c++) rgba.data[i+c]=(1-heat)*rgba.data[i+c]+heat*[255,92,72][c];
  }
  ctx.putImageData(rgba,0,0);
  const verdict=score>model.threshold ? 'Flagged for review' : 'Below review threshold';
  status.textContent=verdict+' · score '+score.toFixed(6)+' · cutoff '+model.threshold.toFixed(6);
  if(knownScore!==undefined) {
    const difference=Math.abs(score-knownScore);
    status.textContent+=' · Python reference difference '+difference.toExponential(2);
    status.dataset.parity=String(difference);
  } else {
    delete status.dataset.parity;
  }
}
document.getElementById('visa-example').addEventListener('click', () => {
  const img=new Image();
  img.onload=()=>inspect(img,model.expected);
  img.onerror=()=>{status.textContent='The example could not be opened.';};
  img.src=model.example;
});
document.getElementById('visa-input').addEventListener('change', async event => {
  const item=event.target.files[0];
  if(!item) return;
  if(item.size>15*1024*1024) { status.textContent='Choose an image smaller than 15 MB.'; return; }
  try {
    const image=await createImageBitmap(item);
    try { inspect(image); } finally { image.close(); }
  } catch {
    status.textContent='This image could not be decoded.';
  }
});
"""


def encode(array):
    return b64encode(array.detach().cpu().numpy().astype("<f4").tobytes()).decode("ascii")


def portable_layers(network):
    layers = []
    for index, layer in enumerate(network):
        if not isinstance(layer, nn.Conv2d):
            continue
        weight, bias = layer.weight, layer.bias
        subsequent = network[index + 1] if index + 1 < len(network) else None
        if isinstance(subsequent, nn.BatchNorm2d):
            scale = subsequent.weight / (subsequent.running_var + subsequent.eps).sqrt()
            weight = weight * scale[:, None, None, None]
            bias = (bias - subsequent.running_mean) * scale + subsequent.bias
        layers.append({
            "cin": layer.in_channels, "cout": layer.out_channels, "k": layer.kernel_size[0],
            "s": layer.stride[0], "p": layer.padding[0], "w": encode(weight), "b": encode(bias),
            "activate": subsequent is not None,
        })
    return layers


@torch.no_grad()
def attach(path, models, report, example_image):
    model_name = "pcb1"
    category = next((row for row in report["categories"] if row["category"] == model_name), None)
    if category is None:
        return
    network = PatchNet().eval()
    network.load_state_dict(torch.load(models / "pcb1.pt", map_location="cpu", weights_only=True))
    image = torch.from_numpy(example_image.transpose(2, 0, 1).copy()).to(torch.float32)[None] / 255
    values = network(image).sigmoid().flatten()
    payload = {"layers": portable_layers(network), "example": png_data(example_image),
               "threshold": category["metrics"][METHODS[0]]["threshold"],
               "expected": float(values.topk(2).values.mean())}
    html = path.read_text(encoding="utf-8")
    if 'id="visa-weights"' in html:
        return
    html = html.replace('<section class="panel"><h2>Results by category', SECTION + '<section class="panel"><h2>Results by category')
    exported = f'<script type="application/json" id="visa-weights">{json.dumps(payload, separators=(",", ":"))}</script>'
    html = html.replace("</body>", exported + "<script>" + SCRIPT + "</script></body>")
    tmp = path.with_suffix(".tmp")
    tmp.write_text(html, encoding="utf-8")
    tmp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    args = parser.parse_args()
    records = load_manifest(args.manifest)
    keys = sorted(key for key, row in records.items() if row == ("pcb1", "test", True))
    file_id = hashlib.sha256(keys[0].encode()).hexdigest()
    image = np.load(args.run / "cache" / "pcb1" / f"{file_id}.npy", allow_pickle=False)
    report = json.loads((args.run / "report.json").read_text())
    attach(args.run / "index.html", args.run / "models", report, image)


if __name__ == "__main__":
    main()
