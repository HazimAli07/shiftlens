"""Train a shared patch network and a classical per-camera baseline.

The network sees normal parts during fitting. Local corruptions supply patch
labels, so annotated defects from held-out parts stay outside training.
"""

import numpy as np
from sklearn.neural_network import MLPClassifier

from .dataset import CAMERAS, read_rgb

HIDDEN_WIDTHS = (64, 32, 16)


def patchify(image, patch_size):
    height, width, channels = image.shape
    if height % patch_size or width % patch_size:
        raise ValueError("Image dimensions must be multiples of patch size.")
    grid = (height // patch_size, width // patch_size)
    patches = image.reshape(grid[0], patch_size, grid[1], patch_size, channels)
    return patches.transpose(0, 2, 1, 3, 4).reshape(grid[0] * grid[1], -1) / np.float32(255), grid


def corrupt(clean, rng, patch_size):
    """Simulate local highlights, pits, and sharp marks on normal patches."""
    batch = clean.copy().reshape(-1, patch_size, patch_size, 3)
    for index, patch in enumerate(batch):
        row, col = rng.integers(1, patch_size - 1, size=2)
        width = int(rng.integers(1, 4))
        if index % 3 == 0:
            patch[max(0, row - width):row + 1, max(0, col - width):col + 2] += 0.5
        elif index % 3 == 1:
            patch[row:row + 2, :] -= 0.6
        else:
            patch[:, col:col + 2] += 0.5
    return batch.reshape(clean.shape).clip(0, 1)


def fit_models(views, size, patch_size, epochs, seed, progress):
    rng = np.random.default_rng(seed)
    net = MLPClassifier(hidden_layer_sizes=HIDDEN_WIDTHS, batch_size=128, random_state=seed)
    # Fixed camera positions let the baseline learn normal appearance per patch location.
    totals = {}
    squares = {}
    counts = {camera: 0 for camera in CAMERAS}
    for epoch in range(epochs):
        for index in rng.permutation(len(views)):
            view = views[index]
            features, _ = patchify(read_rgb(view.path, size), patch_size)
            if epoch == 0:
                camera = view.camera
                counts[camera] += 1
                if camera not in totals:
                    totals[camera] = np.zeros_like(features, dtype=np.float64)
                    squares[camera] = np.zeros_like(features, dtype=np.float64)
                totals[camera] += features
                squares[camera] += features ** 2
            # Bound the number of patches sent to the optimizer independently of image size.
            selected = rng.choice(len(features), min(128, len(features)), replace=False)
            clean = features[selected]
            positives = corrupt(clean, rng, patch_size)
            inputs = np.concatenate((clean, positives))
            targets = np.repeat((0, 1), len(clean))
            order = rng.permutation(len(inputs))
            net.partial_fit(inputs[order], targets[order], classes=(0, 1))
        progress(f"Epoch {epoch + 1}/{epochs} | latest minibatch loss {net.loss_:.4f}")

    templates = {}
    for camera in CAMERAS:
        mean = totals[camera] / counts[camera]
        variance = squares[camera] / counts[camera] - mean ** 2
        templates[camera] = (mean, np.sqrt(np.maximum(variance, 0.0025)))
    return net, templates


def score_view(image, camera, models, patch_size):
    net, templates = models
    patches, grid = patchify(image, patch_size)
    learned = net.predict_proba(patches)[:, 1]
    mean, scale = templates[camera]
    residual = np.mean(np.abs(patches - mean) / scale, axis=1)
    return {"network": learned.reshape(grid), "template": residual.reshape(grid)}


def image_score(score_map):
    scores = score_map.ravel()
    count = min(2, len(scores))
    return float(np.partition(scores, -count)[-count:].mean())


def save_weights(path, net):
    weights = {f"weight_{i}": weight for i, weight in enumerate(net.coefs_)}
    biases = {f"bias_{i}": bias for i, bias in enumerate(net.intercepts_)}
    np.savez_compressed(path, **weights, **biases)
