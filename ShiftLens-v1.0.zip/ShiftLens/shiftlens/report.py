"""Generate an offline report with provenance and inspection evidence."""

from base64 import b64encode
from html import escape
import struct
import zlib

import numpy as np

from .dataset import read_rgb
from .model import image_score

CSS = """
:root{color-scheme:dark;--bg:#0e1218;--card:#161c25;--line:#2a3544;--ink:#f3f7ff;--muted:#aab8cb;--mint:#8beac0}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,sans-serif}
main,header>div{max-width:1160px;margin:auto;padding:0 30px}header{border-bottom:1px solid var(--line)}
header>div{min-height:64px;display:flex;align-items:center;justify-content:space-between;gap:16px}
.name{font-size:19px;letter-spacing:-.03em}.name b{color:var(--mint)}
.tag{border:1px solid #4d594e;background:#26382f;padding:5px 10px;border-radius:5px;color:var(--mint);font:12px ui-monospace,monospace}
.hero{padding:53px 0 30px}.eyebrow{color:var(--mint);font:13px ui-monospace,monospace;letter-spacing:.08em}
h1{font-size:clamp(36px,6vw,64px);letter-spacing:-.065em;line-height:1.04;margin:12px 0 14px}
h2{font-size:24px;letter-spacing:-.032em;margin:0 0 6px}.muted,p{color:var(--muted)} p{margin:6px 0 14px}
.stats,.cameras{display:grid;gap:10px}.stats{grid-template-columns:repeat(3,1fr);margin:0 0 22px}
.metric,.panel{background:var(--card);border:1px solid var(--line);border-radius:12px}.metric{padding:17px 20px}
.metric strong{display:block;font-size:32px;letter-spacing:-.05em;color:var(--mint)}
.panel{padding:22px;margin-bottom:16px}.table{overflow:auto}table{border-collapse:collapse;width:100%;text-align:left;white-space:nowrap}
th,td{padding:11px 10px;border-bottom:1px solid var(--line)}th{color:var(--muted);font-weight:500}
tbody tr:last-child td{border-bottom:0}.highlight{color:var(--mint);font-weight:650}
.cameras{grid-template-columns:repeat(5,1fr);padding:12px 0}
figure{margin:0;min-width:0}figure img{width:100%;display:block;image-rendering:pixelated;border:1px solid var(--line);border-radius:6px}
figcaption{padding-top:5px;font:12px/1.4 ui-monospace,monospace;color:var(--muted)}
details{border-top:1px solid var(--line);padding:10px 0}summary{cursor:pointer;font-weight:650}summary span{margin-left:9px;font-weight:400;color:var(--muted)}
footer{padding:13px 0 40px;color:var(--muted)}a{color:var(--mint)}
@media(max-width:640px){main,header>div{padding-left:14px;padding-right:14px}.panel,.metric{padding:12px}.cameras{grid-template-columns:repeat(2,1fr)}.metric strong{font-size:24px}.hero{padding-top:34px}}
"""


def png_data(image):
    height, width, _ = image.shape

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    raw = b"".join(b"\0" + row.tobytes() for row in image)
    header = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    return "data:image/png;base64," + b64encode(png).decode("ascii")


def overlay(image, scores):
    patch = image.shape[0] // scores.shape[0]
    strength = np.repeat(np.repeat(scores, patch, axis=0), patch, axis=1)[..., None]
    alpha = np.clip((strength - 0.1) * 0.9, 0, 0.72)
    return ((1 - alpha) * image + alpha * np.array([255, 92, 72])).astype(np.uint8)


def render_cases(examples, size, threshold):
    if not examples:
        return ""
    rows = []
    for index, (row, views, maps) in enumerate(examples):
        figures = []
        for camera, view in sorted(views.items()):
            scores = maps[camera]["network"]
            uri = png_data(overlay(read_rgb(view.path, size), scores))
            figures.append(f'<figure><img alt="Camera {camera} anomaly overlay" src="{uri}">'
                           f'<figcaption>C{camera} · score {image_score(scores):.3f}</figcaption></figure>')
        actual = "Defect present" if row.defect else "Normal part"
        decision = "Flagged" if row.scores["network-multi"] > threshold else "Passed"
        state = " open" if index == 0 else ""
        rows.append(f'<details{state}><summary>{escape(row.part)}<span>{actual} · {decision}</span></summary>'
                    f'<div class="cameras">{"".join(figures)}</div></details>')
    return ('<section class="panel"><h2>Inspect the camera views</h2>'
            '<p>Coral shows where the model assigned higher anomaly scores. Open a part to see all five views.</p>'
            + "".join(rows) + "</section>")


def write_report(path, data, examples, size, fixture):
    metrics = data["metrics"]
    names = {
        "network-c1": "Patch network · C1",
        "network-multi": "Patch network · 5 views",
        "template-c1": "Reference template · C1",
        "template-multi": "Reference template · 5 views",
    }
    rows = []
    for key, method in metrics.items():
        emphasis = ' class="highlight"' if key == "network-multi" else ""
        rows.append(f'<tr{emphasis}><td>{names[key]}</td><td>{method["recall"]:.1%}</td>'
                    f'<td>{method["false_rejects_per_1000"]:.1f}</td><td>{method["auroc"]:.3f}</td>'
                    f'<td>{method["average_precision"]:.3f}</td></tr>')
    stage = "Synthetic fixture" if fixture else "Real-IAD experiment"
    provenance = ("This run used procedurally generated images to verify the pipeline. "
                  "The results do not measure performance on factory images." if fixture else
                  "This run used one Real-IAD category and the official held-out test split. "
                  "The report contains aggregate metrics.")
    category = escape(data["category"])
    show = render_cases(examples, size, metrics["network-multi"]["threshold"])
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ShiftLens · Visual Inspection Benchmark</title><style>{CSS}</style></head>
<body><header><div><strong class="name">Shift<b>Lens</b></strong><span class="tag">{stage}</span></div></header>
<main><section class="hero"><div class="eyebrow">VISUAL INSPECTION BENCHMARK</div>
<h1>One part. Five views.</h1><p>Compare defect detection and false rejects at the physical-part level.</p></section>
<div class="stats">
<div class="metric"><span class="muted">Training parts</span><strong>{data["fit_parts"]}</strong></div>
<div class="metric"><span class="muted">Calibration parts</span><strong>{data["calibration_parts"]}</strong></div>
<div class="metric"><span class="muted">Held-out test parts</span><strong>{data["test_parts"]}</strong></div></div>
<section class="panel"><h2>Model comparison</h2>
<p>Each method sets its own threshold using normal calibration parts at a {data["calibration_fpr"]:.0%} false-reject budget.</p>
<div class="table"><table><thead><tr><th>Method</th><th>Defect recall</th><th>False rejects per 1,000 good</th>
<th>AUROC</th><th>Average precision</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div></section>
{show}
<section class="panel"><h2>Run provenance</h2><p>{provenance}</p>
<p>Category {category} · Seed {data["seed"]} · {data["epochs"]} epochs · {size}px inputs · {data["patch_size"]}px patches</p>
<p>Incomplete parts excluded: {data["discarded"]["incomplete_train"]} from training and {data["discarded"]["incomplete_test"]} from testing.</p></section>
<footer>ShiftLens research benchmark · <a href="https://realiad4ad.github.io/Real-IAD/">Real-IAD dataset</a></footer>
</main></body></html>"""
    path.write_text(html, encoding="utf-8")
