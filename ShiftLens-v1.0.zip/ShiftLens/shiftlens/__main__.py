"""Command-line entry point for a fixture or Real-IAD experiment."""

import argparse
import json
from pathlib import Path
import tempfile

from .dataset import load_realiad, partition
from .evaluate import predict, summarize
from .fixtures import generate
from .model import fit_models, save_weights
from .report import write_report


def main():
    parser = argparse.ArgumentParser(prog="shiftlens", description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--fixture", action="store_true", help="Generate small artificial camera images.")
    source.add_argument("--dataset", type=Path, help="Path to extracted Real-IAD.")
    parser.add_argument("--category", default="audiojack")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--calibration-fpr", type=float, default=0.05)
    args = parser.parse_args()
    if args.epochs < 1 or not 0 <= args.calibration_fpr < 1:
        parser.error("Use positive epochs and a calibration FPR in [0, 1).")
    try:
        with tempfile.TemporaryDirectory(prefix="shiftlens-") as tmp:
            run(args, Path(tmp))
    except (OSError, ValueError, KeyError, ImportError) as error:
        parser.exit(2, f"ShiftLens: {error}\n")


def run(args, tmp):
    if args.fixture:
        train, test = generate(tmp, args.seed)
        source, size = "Synthetic fixture", 64
    else:
        train, test = load_realiad(args.dataset, args.category)
        source, size = "Real-IAD", 256
    patch_size = 8
    fit, calibration, test, dropped = partition(train, test, args.seed)
    print(f"{source} | {len(fit) // 5} fit parts | {len(calibration)} calibration parts | "
          f"{len(test)} test parts", flush=True)
    models = fit_models(fit, size, patch_size, args.epochs, args.seed, lambda text: print(text, flush=True))
    eval_cal = [row for row, _ in predict(calibration, models, size, patch_size)]
    eval_test, examples = [], []
    for row, maps in predict(test, models, size, patch_size):
        eval_test.append(row)
        if args.fixture and len(examples) < 6:
            examples.append((row, test[row.part], maps))
    metrics = summarize(eval_cal, eval_test, args.calibration_fpr)
    summary = {
        "dataset": source,
        "category": "demo-board" if args.fixture else args.category,
        "seed": args.seed,
        "epochs": args.epochs,
        "image_size": size,
        "patch_size": patch_size,
        "calibration_fpr": args.calibration_fpr,
        "fit_parts": len(fit) // 5,
        "calibration_parts": len(calibration),
        "test_parts": len(test),
        "discarded": dropped,
        "metrics": metrics,
    }
    args.out.mkdir(parents=True, exist_ok=True)
    save_weights(args.out / "network.npz", models[0])
    report = args.out / "report.json"
    report.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    write_report(args.out / "index.html", summary, examples, size, args.fixture)
    print(f"Results: {args.out / 'index.html'}", flush=True)


if __name__ == "__main__":
    main()
