"""Train and benchmark a convolutional detector on the official VisA 1-class split."""

import argparse
from collections import defaultdict
import csv
import hashlib
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import tarfile
from time import perf_counter

import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.nn import functional as F

from .evaluate import Prediction, summarize
from .model import image_score, patchify
from .visa_report import save_dashboard

SIZE = 128
PATCH = 8
METHODS = ("Convolutional detector", "Reference template")


def load_manifest(path):
    records = {}
    with path.open(newline="", encoding="utf-8-sig") as manifest:
        for row in csv.DictReader(manifest):
            name = PurePosixPath(row["image"])
            category, split, label = row["object"], row["split"], row["label"]
            if (not name.parts or name.parts[0] != category or name.is_absolute()
                    or ".." in name.parts or name.as_posix() in records
                    or (split, label) not in {("train", "normal"), ("test", "normal"), ("test", "anomaly")}):
                raise ValueError(f"Invalid or repeated manifest entry: {name}")
            records[name.as_posix()] = (category, split, label == "anomaly")
    if not records:
        raise ValueError("The 1-class CSV is empty.")
    return records


def load_archive(path, records, cache):
    """Decode only requested regular JPEG records from the official archive."""
    by_category = defaultdict(list)
    remaining = dict(records)
    pending = 0
    for category, _, _ in records.values():
        (cache / category).mkdir(exist_ok=True, parents=True)
    with tarfile.open(path, mode="r:") as archive:
        for member in archive:
            raw = PurePosixPath(member.name)
            if raw.is_absolute() or ".." in raw.parts or not member.isfile():
                continue
            # The release may have a top-level folder above the category.
            key = "/".join(raw.parts[-4:])
            if key not in remaining:
                key = "/".join(raw.parts[-5:])
            if key not in remaining:
                continue
            category, split, defect = remaining.pop(key)
            if member.size > 100 * 1024 * 1024:
                raise ValueError(f"Unexpected image size: {member.name}")
            with archive.extractfile(member) as entry, Image.open(BytesIO(entry.read())) as image:
                image.draft("RGB", (SIZE, SIZE))
                pixels = np.asarray(image.convert("RGB").resize((SIZE, SIZE), Image.Resampling.BILINEAR))
            target = cache / category / (hashlib.sha256(key.encode()).hexdigest() + ".npy")
            np.save(target, pixels, allow_pickle=False)
            by_category[category].append((key, split, defect, target))
            pending += 1
            if pending % 1500 == 0:
                print(f"Decoded {pending:,}/{len(records):,} source images", flush=True)
    if remaining:
        raise ValueError(f"Archive is missing {len(remaining)} manifest images, for example {next(iter(remaining))}.")
    return by_category


def load_images(rows):
    return np.stack([np.load(row[3], allow_pickle=False) for row in rows])


def split_category(rows, seed):
    train = sorted((row for row in rows if row[1] == "train"),
                   key=lambda row: hashlib.sha256(f"{seed}|{row[0]}".encode()).digest())
    test = sorted((row for row in rows if row[1] == "test"), key=lambda row: row[0])
    if len(train) < 5 or {row[2] for row in test} != {True, False}:
        raise ValueError("Each category needs normal training data and both held-out test labels.")
    count = max(1, len(train) // 5)
    return train[count:], train[:count], test


class PatchNet(nn.Sequential):
    """The three stride-2 convolutions produce one defect score per 8 × 8 region."""

    def __init__(self):
        super().__init__(
            nn.Conv2d(3, 16, 5, stride=2, padding=2), nn.BatchNorm2d(16), nn.GELU(),
            nn.Conv2d(16, 24, 3, stride=2, padding=1), nn.BatchNorm2d(24), nn.GELU(),
            nn.Conv2d(24, 32, 3, stride=2, padding=1), nn.BatchNorm2d(32), nn.GELU(),
            nn.Conv2d(32, 32, 3, padding=1), nn.GELU(), nn.Conv2d(32, 1, 1),
        )


def distort(clean, rng):
    changed = clean.copy()
    target = np.zeros((len(clean), SIZE // PATCH, SIZE // PATCH), dtype=np.float32)
    for i, image in enumerate(changed):
        for repeat in range(int(rng.integers(1, 4))):
            row, col = rng.integers(1, SIZE // PATCH - 2, size=2)
            y, x = row * PATCH, col * PATCH
            patch = image[y:y + PATCH * 2, x:x + PATCH * 2]
            if (i + repeat) % 3 == 0:
                other_y, other_x = rng.integers(0, SIZE - PATCH * 2, size=2)
                donor = clean[i, other_y:other_y + PATCH * 2, other_x:other_x + PATCH * 2]
                patch[:] = patch * 0.35 + donor * 0.65
            elif (i + repeat) % 3 == 1:
                patch[5:11] += rng.uniform(0.18, 0.5) * rng.choice((-1, 1))
            else:
                patch[:, 5:11] *= rng.uniform(0.35, 0.72)
            target[i, row:row + 2, col:col + 2] = 1
    changed = changed.clip(0, 1)
    return np.concatenate((clean, changed)), np.concatenate((np.zeros_like(target), target))


def train_net(fit, device, epochs, batch_size, seed, progress):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    model = PatchNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
    weight = torch.tensor(8.0, device=device)
    for epoch in range(epochs):
        model.train()
        losses = []
        for batch in np.array_split(rng.permutation(len(fit)), (len(fit) + batch_size - 1) // batch_size):
            clean = fit[batch].astype(np.float32) / 255
            exposure = rng.uniform(0.92, 1.08, size=(len(batch), 1, 1, 1)).astype(np.float32)
            inputs, target = distort((clean * exposure).clip(0, 1), rng)
            inputs = torch.from_numpy(inputs.transpose(0, 3, 1, 2).copy()).to(device)
            target = torch.from_numpy(target).to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(inputs)[:, 0]
            loss = F.binary_cross_entropy_with_logits(logits, target, pos_weight=weight)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        progress(epoch + 1, float(np.mean(losses)))
    return model.eval()


def fit_template(images):
    total = None
    squared = None
    for image in images:
        patches, _ = patchify(image, PATCH)
        if total is None:
            total = np.zeros_like(patches, dtype=np.float64)
            squared = np.zeros_like(patches, dtype=np.float64)
        total += patches
        squared += patches ** 2
    mean = total / len(images)
    scale = np.sqrt(np.maximum(squared / len(images) - mean ** 2, 0.0025))
    return mean, scale


@torch.no_grad()
def score(rows, images, model, template, device, batch_size):
    output, maps = [], {}
    mean, scale = template
    for start in range(0, len(rows), batch_size):
        chunk = images[start:start + batch_size]
        inputs = torch.from_numpy(chunk.transpose(0, 3, 1, 2).copy()).to(device, dtype=torch.float32) / 255
        anomaly = model(inputs)[:, 0].sigmoid().cpu().numpy()
        for i, image in enumerate(chunk):
            key, _, actual, _ = rows[start + i]
            patches, grid = patchify(image, PATCH)
            residual = (np.abs(patches - mean) / scale).mean(axis=1).reshape(grid)
            output.append(Prediction(key, actual, {
                METHODS[0]: image_score(anomaly[i]),
                METHODS[1]: image_score(residual),
            }))
            maps[key] = anomaly[i]
    return output, maps


def evaluate_category(category, rows, args, device, models_dir):
    fit_rows, calibration, test = split_category(rows, args.seed)
    fit = load_images(fit_rows)
    print(f"{category} | {len(fit_rows)} train, {len(calibration)} calibration, {len(test)} test", flush=True)
    model = train_net(fit, device, args.epochs, args.batch_size, args.seed,
                      lambda epoch, loss: print(f"  epoch {epoch}/{args.epochs} · loss {loss:.4f}", flush=True))
    template = fit_template(fit)
    cal, _ = score(calibration, load_images(calibration), model, template, device, args.batch_size)
    test_images = load_images(test)
    predictions, maps = score(test, test_images, model, template, device, args.batch_size)
    metrics = summarize(cal, predictions, args.calibration_fpr)
    examples = []
    for desired in (True, False):
        i, row = next((i, row) for i, row in enumerate(predictions) if row.defect == desired)
        examples.append((row, test_images[i], maps[row.part]))
    torch.save({k: v.cpu() for k, v in model.state_dict().items()}, models_dir / f"{category}.pt")
    return {"category": category, "train": len(fit_rows), "calibration": len(calibration),
            "test": len(test), "metrics": metrics}, examples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--category", action="append", help="Repeat to benchmark a subset. Default is all twelve.")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--calibration-fpr", type=float, default=0.05)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda", "mps"), default="auto")
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1 or not 0 <= args.calibration_fpr < 1:
        parser.error("Use positive epochs and batch size, and a calibration FPR in [0, 1).")
    try:
        run(args)
    except (OSError, ValueError, KeyError, RuntimeError, tarfile.TarError) as error:
        parser.exit(2, f"ShiftLens VisA: {error}\n")


def run(args):
    started = perf_counter()
    device = args.device
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    if device == "cpu":
        torch.set_num_threads(min(torch.get_num_threads(), 4))
    manifest = load_manifest(args.manifest)
    if args.category:
        unknown = set(args.category) - {row[0] for row in manifest.values()}
        if unknown:
            raise ValueError(f"Unknown categories: {sorted(unknown)}")
        manifest = {key: row for key, row in manifest.items() if row[0] in args.category}
    args.out.mkdir(parents=True, exist_ok=True)
    models = args.out / "models"
    models.mkdir(exist_ok=True)
    cache = args.out / "cache"
    print(f"VisA official 1-class split | {len(manifest):,} source images | PyTorch {torch.__version__} · {device}",
          flush=True)
    by_category = load_archive(args.archive, manifest, cache)
    summaries, cases = [], {}
    for category in sorted(by_category):
        summary, examples = evaluate_category(category, by_category[category], args, device, models)
        summaries.append(summary)
        cases[category] = examples
        (args.out / "progress.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
    report = {"dataset": "Amazon Science VisA", "split": "Official 1-class", "images": len(manifest),
              "input_pixels": SIZE, "patch_pixels": PATCH, "device": device,
              "torch_version": torch.__version__, "seed": args.seed, "epochs": args.epochs,
              "batch_size": args.batch_size, "calibration_fpr": args.calibration_fpr,
              "manifest_sha256": hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
              "elapsed_seconds": round(perf_counter() - started, 2), "categories": summaries}
    (args.out / "report.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    save_dashboard(args.out / "index.html", report, cases, METHODS)
    print(f"Completed {len(summaries)} categories. Results: {args.out / 'index.html'}", flush=True)


if __name__ == "__main__":
    main()
