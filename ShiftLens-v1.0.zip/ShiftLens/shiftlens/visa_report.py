"""Write a standalone Chrome dashboard for a completed VisA run."""

from html import escape
from statistics import mean

from .report import CSS, overlay, png_data


def format_rate(value):
    return f"{value:.1%}"


def save_dashboard(path, report, cases, methods):
    categories = report["categories"]
    names = ("CNN", "Template")
    totals = {method: {key: sum(row["metrics"][method][key] for row in categories)
                       for key in ("true_rejects", "false_rejects", "normal_test_parts", "defective_test_parts")}
              for method in methods}
    rows, inspections = [], []
    for row in categories:
        category = escape(row["category"])
        first, second = (row["metrics"][method] for method in methods)
        rows.append(f'<tr><td><a href="#{category}">{category}</a></td><td>{row["test"]:,}</td>'
                    f'<td>{format_rate(first["recall"])}</td><td>{format_rate(second["recall"])}</td>'
                    f'<td>{first["false_rejects_per_1000"]:.0f}</td><td>{second["false_rejects_per_1000"]:.0f}</td>'
                    f'<td>{first["auroc"]:.3f}</td><td>{second["auroc"]:.3f}</td></tr>')
        figures = []
        for prediction, image, scores in cases[row["category"]]:
            actual = "Defective" if prediction.defect else "Good"
            decision = "Flagged" if prediction.scores[methods[0]] > first["threshold"] else "Passed"
            original_uri, overlay_uri = png_data(image), png_data(overlay(image, scores))
            figures.append(f'<figure><div class="pair"><img alt="{category} input image" src="{original_uri}">'
                           f'<img alt="{category} model heatmap" src="{overlay_uri}"></div>'
                           f'<figcaption>{actual} · {decision} · Score {prediction.scores[methods[0]]:.3f}'
                           f' · Cutoff {first["threshold"]:.3f}</figcaption></figure>')
        inspections.append(f'<details id="{category}"><summary>{category} <span>{row["test"]} held-out images</span></summary>'
                           f'<div class="examples">{"".join(figures)}</div></details>')
    overall = []
    for index, method in enumerate(methods):
        t = totals[method]
        recall = t["true_rejects"] / t["defective_test_parts"]
        false_rejects = t["false_rejects"] * 1000 / t["normal_test_parts"]
        auc = mean(row["metrics"][method]["auroc"] for row in categories)
        overall.append(f'<tr><td>{names[index]}</td><td>{t["true_rejects"]:,}/{t["defective_test_parts"]:,} '
                       f'({format_rate(recall)})</td><td>{t["false_rejects"]:,}/{t["normal_test_parts"]:,} '
                       f'({false_rejects:.1f} per 1,000)</td><td>{auc:.3f}</td></tr>')
    extra = """.examples{display:grid;grid-template-columns:repeat(2,1fr);gap:18px;margin:14px 0}
.pair{display:grid;grid-template-columns:1fr 1fr;gap:7px}.pair img{image-rendering:auto}
td:first-child{font-weight:650}thead th{text-wrap:balance}.footnote{font-size:13px}
@media(max-width:640px){.examples{grid-template-columns:1fr}}"""
    test = sum(row["test"] for row in categories)
    device = escape(report["device"].upper())
    label = f"VisA · {device}"
    duration = report["elapsed_seconds"]
    dashboard = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ShiftLens · Real Industrial Inspection</title><style>{CSS}{extra}</style></head>
<body><header><div><strong class="name">Shift<b>Lens</b></strong><span class="tag">{label}</span></div></header>
<main>
<section class="hero"><div class="eyebrow">INDUSTRIAL VISION BENCHMARK</div><h1>Catch defects.<br>Keep good parts moving.</h1>
<p>Two detectors. One published test split. Each category gets a threshold calibrated on separate normal images.</p></section>
<div class="stats">
<div class="metric"><span class="muted">Real source images</span><strong>{report["images"]:,}</strong></div>
<div class="metric"><span class="muted">Object categories</span><strong>{len(categories)}</strong></div>
<div class="metric"><span class="muted">Held-out test images</span><strong>{test:,}</strong></div></div>
<section class="panel"><h2>Benchmark results</h2><p>Recall and false rejects use held-out images. AUROC is averaged across categories.</p>
<div class="table"><table><thead><tr><th>Detector</th><th>Defects caught</th><th>Good images rejected</th>
<th>Mean AUROC</th></tr></thead><tbody>{"".join(overall)}</tbody></table></div></section>
<section class="panel"><h2>Results by category</h2>
<p>Thresholds use an empirical {report["calibration_fpr"]:.0%} false-reject budget on calibration data. Test rates can differ.</p>
<div class="table"><table><thead><tr><th>Category</th><th>Test images</th><th>CNN recall</th><th>Template recall</th>
<th>CNN false rejects / 1,000</th><th>Template false rejects / 1,000</th><th>CNN AUROC</th><th>Template AUROC</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table></div></section>
<section class="panel"><h2>Inspect real test images</h2>
<p>Original on the left. Model overlay on the right. Coral marks regions that received higher scores. The model was trained on artificially altered regions of normal training images.</p>
{"".join(inspections)}</section>
<section class="panel"><h2>Run provenance</h2>
<p>Amazon Science VisA · Official 1-class split · {report["epochs"]} training epochs per category · {device} · {duration / 60:.1f} minutes</p>
<p>Input {report["input_pixels"]} × {report["input_pixels"]} · Score grid cells {report["patch_pixels"]} × {report["patch_pixels"]} input pixels · Seed {report["seed"]}.</p>
<p class="footnote">Single-view images. Image-level benchmarking uses published test labels. Heatmaps show model output and do not measure pixel-level accuracy.</p></section>
<footer>Images from Zou et al., <a href="https://registry.opendata.aws/visa/">VisA</a> under
<a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. Example images are resized and overlaid with model scores.</footer>
</main>
<script>
for (const link of document.querySelectorAll('td a')) {{
  link.addEventListener('click', () => {{ const item = document.getElementById(link.hash.slice(1)); if (item) item.open = true; }});
}}
</script></body></html>"""
    path.write_text(dashboard, encoding="utf-8")
