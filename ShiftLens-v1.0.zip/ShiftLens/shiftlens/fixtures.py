"""Procedural images for end-to-end tests. Never treat these as Real-IAD data."""

import numpy as np

from .dataset import CAMERAS, View


def generate(root, seed):
    rng = np.random.default_rng(seed)
    root.mkdir(parents=True, exist_ok=True)
    height, width = np.mgrid[:64, :64]
    splits = []
    for split, count in (("train", 60), ("test", 36)):
        views = []
        for item in range(count):
            part = f"{split}-{item:03d}"
            defect_camera = (item % 5) + 1 if split == "test" and item % 2 == 0 else None
            offset = rng.uniform(-9, 9)
            for camera in CAMERAS:
                rgb = np.empty((64, 64, 3), dtype=np.float32)
                rgb[:] = (23, 31, 38)
                board = (width > 5) & (width < 58) & (height > 6) & (height < 57)
                rgb[board] = (63, 112, 104)
                internal = (width > 9) & (width < 54) & (height > 10) & (height < 53)
                traces = internal & (((width + 2 * camera) % 9 == 0) | ((height + camera) % 11 == 0))
                rgb[traces] = (135, 158, 124)
                chip = (abs(width - (28 + camera)) < 10) & (abs(height - 32) < 8)
                rgb[chip] = (42, 57, 69)
                for cx, cy in ((13, 14), (50, 14), (13, 49), (50, 49)):
                    rgb[(width - cx) ** 2 + (height - cy) ** 2 <= 12] = (170, 177, 162)
                rgb += ((width - 32) * (camera - 3) * 0.19 + offset)[..., None]
                rgb += rng.normal(0, 3, rgb.shape)
                defect = camera == defect_camera
                if defect:
                    cx, cy = int(rng.integers(18, 46)), int(rng.integers(19, 44))
                    damage = (abs(height - cy - (width - cx) // 3) < 2) & (abs(width - cx) < 10)
                    rgb[damage] = rng.uniform(215, 252, (damage.sum(), 3))
                path = root / f"{part}-C{camera}.npy"
                np.save(path, rgb.clip(0, 255).astype(np.uint8), allow_pickle=False)
                views.append(View(part, camera, path, defect))
        splits.append(views)
    return splits
