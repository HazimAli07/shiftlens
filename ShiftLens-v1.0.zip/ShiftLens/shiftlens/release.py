"""Build the complete static inspection app from verified VisA artifacts."""

import argparse
from pathlib import Path
import hashlib
import json
import shutil

import numpy as np
from PIL import Image, ImageEnhance
import torch

from .browser import encode, portable_layers
from .retrieval import METHOD, cache_rows
from .visa import METHODS, PatchNet, fit_template, load_images, score, split_category


def dump(path, value):
    path.write_text(json.dumps(value, separators=(",", ":"), allow_nan=False), encoding="utf-8")


def script(path, namespace, value):
    payload = json.dumps(value, separators=(",", ":"), allow_nan=False).replace("<", "\\u003c")
    path.write_text(f"window.{namespace}={payload};\n", encoding="utf-8")


@torch.no_grad()
def build(run, manifest, source, output):
    torch.set_num_threads(2)
    report = json.loads((run / "report.json").read_text())
    if hashlib.sha256(manifest.read_bytes()).hexdigest() != report["manifest_sha256"]:
        raise ValueError("The split manifest differs from the benchmark run.")
    retrieval = json.loads((run / "retrieval.json").read_text()) if (run / "retrieval.json").is_file() else None
    rows = cache_rows(run, manifest)
    assets = output / "assets"
    output.mkdir(parents=True, exist_ok=True)
    assets.mkdir(exist_ok=True)
    for filename in ("index.html", "style.css", "app.js"):
        shutil.copyfile(source / filename, output / filename)
    items = []
    for category in report["categories"]:
        key = category["category"]
        fit, _, test = split_category(rows[key], report["seed"])
        model = PatchNet().eval()
        model.load_state_dict(torch.load(run / "models" / f"{key}.pt", map_location="cpu", weights_only=True))
        template = fit_template(load_images(fit))
        thresholds = {method: category["metrics"][method]["threshold"] for method in METHODS}
        examples = []
        for is_defect in (True, False):
            record = next(row for row in test if row[2] == is_defect)
            image = load_images([record])
            outputs, _ = score([record], image, model, template, "cpu", 1)
            kind = "defect" if is_defect else "normal"
            relative = f"assets/{key}-{kind}.png"
            picture = Image.fromarray(image[0])
            picture.save(output / relative, optimize=True)
            examples.append({"kind": kind, "path": relative, "scores": outputs[0].scores,
                             "source": record[0]})
            if key == "pcb1" and is_defect:
                resized = picture.resize((840, 840), Image.Resampling.LANCZOS)
                ImageEnhance.Contrast(resized).enhance(1.08).save(assets / "inspection.jpg", quality=91)
        model_info = {"category": key, "layers": portable_layers(model),
                      "mean": encode(torch.as_tensor(template[0])),
                      "scale": encode(torch.as_tensor(template[1])),
                      "thresholds": thresholds}
        separate = assets / f"{key}.js"
        payload = json.dumps(model_info, separators=(",", ":"), allow_nan=False)
        separate.write_text(f'window.shiftModels[{json.dumps(key)}]={payload};\n', encoding="utf-8")
        metrics = dict(category["metrics"])
        if retrieval:
            metrics[METHOD] = retrieval["categories"][key]
        items.append({**category, "metrics": metrics, "examples": examples})
        print(f"Exported {key}", flush=True)
    packaged = {**report, "categories": items, "release": "1.0"}
    script(assets / "benchmark.js", "shiftData", packaged)
    dump(assets / "benchmark.json", packaged)
    (output / ".nojekyll").touch()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--source", type=Path, default=Path("web"))
    parser.add_argument("--output", type=Path, default=Path("docs"))
    args = parser.parse_args()
    build(args.run, args.manifest, args.source, args.output)
