"""Load camera views and enforce physical-part split boundaries."""

from collections import defaultdict
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re

import numpy as np

CAMERAS = tuple(range(1, 6))
REAL_NAME = re.compile(r"^(.+_\d{4}_[A-Z][A-Z_]*[A-Z])_C([1-5])_")


@dataclass(frozen=True)
class View:
    part: str
    camera: int
    path: Path
    defect: bool


def grouped(views):
    parts = defaultdict(dict)
    for view in views:
        if view.camera not in CAMERAS or view.camera in parts[view.part]:
            raise ValueError(f"Invalid or repeated camera for {view.part}: C{view.camera}")
        parts[view.part][view.camera] = view
    return parts


def partition(train, test, seed):
    train_parts, test_parts = grouped(train), grouped(test)
    overlap = train_parts.keys() & test_parts.keys()
    if overlap:
        raise ValueError(f"Physical parts appear in both train and test: {sorted(overlap)[:5]}")
    if any(view.defect for view in train):
        raise ValueError("The training split must contain only normal parts.")
    full_train = [key for key, views in train_parts.items() if len(views) == len(CAMERAS)]
    full_test = [key for key, views in test_parts.items() if len(views) == len(CAMERAS)]
    if len(full_train) < 5 or not full_test:
        raise ValueError("Need five complete training parts and at least one complete test part.")
    full_train.sort(key=lambda key: hashlib.sha256(f"{seed}|{key}".encode()).digest())
    calibration_count = max(1, len(full_train) // 5)
    fit = [view for key in full_train[calibration_count:] for view in train_parts[key].values()]
    calibration = {key: train_parts[key] for key in full_train[:calibration_count]}
    evaluation = {key: test_parts[key] for key in sorted(full_test)}
    dropped = {"incomplete_train": len(train_parts) - len(full_train),
               "incomplete_test": len(test_parts) - len(full_test)}
    return fit, calibration, evaluation, dropped


def load_realiad(root, category):
    if not re.fullmatch(r"[a-z0-9_]+", category):
        raise ValueError("Use a Real-IAD category folder name, such as audiojack.")
    root = root.resolve()
    locations = [
        root / "realiad_jsons" / "realiad_jsons" / f"{category}.json",
        root / "realiad_jsons" / f"{category}.json",
    ]
    metadata = next((path for path in locations if path.is_file()), None)
    if metadata is None:
        raise FileNotFoundError(f"Extract the official multi-view JSON under {locations[-1].parent}.")
    image_root = (root / "realiad_1024" / category).resolve()
    if not image_root.is_relative_to(root):
        raise ValueError("Category path must remain inside the dataset root.")
    data = json.loads(metadata.read_text(encoding="utf-8"))
    splits = []
    for split in ("train", "test"):
        views = []
        for row in data[split]:
            relative = Path(row["image_path"])
            path = (image_root / relative).resolve()
            if not path.is_relative_to(image_root):
                raise ValueError(f"Image path leaves category directory: {relative}")
            match = REAL_NAME.match(path.name)
            if match is None:
                raise ValueError(f"Cannot identify the part and camera: {path.name}")
            if not path.is_file():
                raise FileNotFoundError(f"Missing image: {path}")
            part, camera = match.groups()
            views.append(View(part, int(camera), path, row["anomaly_class"] != "OK"))
        splits.append(views)
    return splits


def read_rgb(path, size):
    if path.suffix == ".npy":
        image = np.load(path, allow_pickle=False)
        if image.shape != (size, size, 3) or image.dtype != np.uint8:
            raise ValueError(f"Unexpected fixture image: {path}")
        return image
    from PIL import Image
    with Image.open(path) as image:
        return np.asarray(image.convert("RGB").resize((size, size), Image.Resampling.BILINEAR))
