"""Calibrate on normal parts, then evaluate complete held-out physical parts."""

from dataclasses import dataclass
import math

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score

from .dataset import read_rgb
from .model import image_score, score_view


@dataclass
class Prediction:
    part: str
    defect: bool
    scores: dict


def predict(parts, models, size, patch_size):
    for part, views in parts.items():
        maps = {}
        for camera, view in sorted(views.items()):
            image = read_rgb(view.path, size)
            maps[camera] = score_view(image, camera, models, patch_size)
        scores = {}
        for method in ("network", "template"):
            by_camera = {camera: image_score(maps[camera][method]) for camera in maps}
            scores[f"{method}-c1"] = by_camera[1]
            scores[f"{method}-multi"] = max(by_camera.values())
        yield Prediction(part, any(view.defect for view in views.values()), scores), maps


def threshold_for_fpr(normal_scores, budget):
    if not normal_scores or not 0 <= budget < 1:
        raise ValueError("Calibration needs normal scores and a budget in [0, 1).")
    if not all(math.isfinite(score) for score in normal_scores):
        raise ValueError("Calibration scores must be finite.")
    ordered = sorted(normal_scores)
    allowance = int(budget * len(ordered))
    return ordered[len(ordered) - allowance - 1]


def summarize(calibration, test, budget):
    if not test or any(row.defect for row in calibration):
        raise ValueError("Use an unseen test set and normal calibration parts.")
    actual = np.asarray([row.defect for row in test])
    if not actual.any() or actual.all():
        raise ValueError("The complete-view test set needs both normal and defective parts.")
    results = {}
    for method in test[0].scores:
        clean = [row.scores[method] for row in calibration]
        threshold = threshold_for_fpr(clean, budget)
        scores = np.asarray([row.scores[method] for row in test])
        rejects = scores > threshold
        positives, negatives = int(actual.sum()), int((~actual).sum())
        true_rejects = int((actual & rejects).sum())
        false_rejects = int((~actual & rejects).sum())
        results[method] = {
            "threshold": threshold,
            "auroc": float(roc_auc_score(actual, scores)),
            "average_precision": float(average_precision_score(actual, scores)),
            "recall": true_rejects / positives,
            "false_rejects_per_1000": 1000 * false_rejects / negatives,
            "true_rejects": true_rejects,
            "false_rejects": false_rejects,
            "normal_test_parts": negatives,
            "defective_test_parts": positives,
            "calibration_false_rejects": sum(score > threshold for score in clean),
            "calibration_parts": len(clean),
        }
    return results
