"""ShiftLens industrial vision research benchmark."""

__version__ = "0.2.0"
