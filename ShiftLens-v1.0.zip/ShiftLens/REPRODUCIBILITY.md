# ShiftLens

An industrial computer-vision benchmark for one operational question. **How many defective parts can we detect without creating an unacceptable number of false rejects?**

The main benchmark trains convolutional detectors on real images from VisA and compares them with a calibrated reference template. A small multi-view learning demo illustrates how to train and evaluate by physical part. The optional Real-IAD adapter extends the multi-view experiment to the authors' research dataset.

## Included reference run

Open `demo/visa/index.html` for the complete 12-category run in Chrome. The results use all 10,821 source images and the official 2,162-image held-out split. Each CNN trained for 3 epochs on CPU.

| Model | Defects caught | Good images rejected | Mean AUROC |
|---|---:|---:|---:|
| Convolutional detector | 122/1,200 | 55/962 | 0.608 |
| Reference template | 343/1,200 | 62/962 | 0.736 |

## Run the real-data benchmark

The [Amazon Science VisA dataset](https://registry.opendata.aws/visa/) contains 10,821 industrial inspection images across 12 categories, including four kinds of printed circuit boards. ShiftLens uses the authors' published one-class split. Each category trains one convolutional detector on normal images with localized corruptions. An independent reference template learns expected appearance at each patch location.

1. Download the [official VisA archive](https://amazon-visual-anomaly.s3.us-west-2.amazonaws.com/VisA_20220922.tar). Keep the archive intact.
2. Use the bundled `benchmark/visa-1cls.csv` or obtain the [original split](https://github.com/amazon-science/spot-diff/blob/main/split_csv/1cls.csv). The benchmark checks that every image listed in the split is present before training.
3. Run the benchmark. Use Python 3.11 or newer and a clean virtual environment.

```sh
python -m pip install -r requirements-dl.txt
python -m shiftlens.visa --archive /path/to/VisA_20220922.tar --manifest benchmark/visa-1cls.csv --out runs/visa
```

Add the browser inference widget after a run that includes the PCB1 category.

```sh
python -m shiftlens.browser --run runs/visa --manifest benchmark/visa-1cls.csv
```

Open `runs/visa/index.html` in Chrome. The widget scores a real held-out PCB1 image or a local upload without a server. It embeds the trained convolution weights and the calibrated PCB1 threshold. The included example also reports its numerical difference from the PyTorch score. The command trains every category by default. To smoke-test a specific category, add `--category pcb1 --epochs 1`. The default device chooses CUDA, Apple MPS, or CPU based on availability. A CUDA-enabled Python build is needed to use an NVIDIA GPU.

The real-data model is a fully convolutional PyTorch network with three downsampling layers and a dense defect head. Calibration uses a separate deterministic subset of official normal training images. The benchmark evaluates image-level recall, false rejects per 1,000 good images, average precision and AUROC on the official test images. The dashboard compares both models and shows images and score overlays. The original dataset is CC BY 4.0 and remains separate from this package.

## Run the learning demo

Requires Python 3.11 or newer.

```sh
python -m pip install -r requirements.txt
python -m shiftlens --fixture --epochs 3 --out runs/demo
python -m unittest discover -s tests -v
```

Open `runs/demo/index.html`. Expand a part and inspect which view contributes to its score. The color overlay is the network's patch score. The fixture uses procedurally generated images and verifies the end-to-end mechanics. It yields no evidence about performance on real factory images.

## Run a Real-IAD category

The authors' [Real-IAD dataset](https://huggingface.co/datasets/Real-IAD/Real-IAD) has around 150,000 images across 30 categories. The authors require account sign-in and acceptance of access conditions. The data is distributed for research under CC BY-NC-SA 4.0. [Official CVPR paper](https://openaccess.thecvf.com/content/CVPR2024/html/Wang_Real-IAD_A_Real-World_Multi-View_Dataset_for_Benchmarking_Versatile_Industrial_Anomaly_Detection_CVPR_2024_paper.html).

1. Download the official multi-view JSON archive and the 1024px ZIP for one category such as `audiojack`. Extract the category under `data/Real-IAD/realiad_1024/audiojack/` and the base JSON so its path is `data/Real-IAD/realiad_jsons/audiojack.json` or `data/Real-IAD/realiad_jsons/realiad_jsons/audiojack.json`. [Official layout](https://github.com/Tencent/AnomalyDetection_Real-IAD).
2. Start with one category and use a separate output directory per category.

```sh
python -m shiftlens --dataset data/Real-IAD --category audiojack --epochs 3 --out runs/audiojack
```

The loader retains the official test split, derives part IDs and camera IDs from the documented filenames, rejects duplicate camera records and train/test overlap, and reports incomplete parts. It takes calibration parts from the normal training split. Modeling only sees the remainder. Real-IAD images and annotations stay in the extracted dataset directory. HTML and JSON for a Real-IAD run include aggregate metrics.

## How it works

| File | Engineering decision |
|---|---|
| `shiftlens/dataset.py` | Split by physical part. Five views of a part share the same split. |
| `shiftlens/model.py` | Stream RGB images through patch extraction. Fit a deep network on simulated patch corruptions and a reference template on normal appearance. |
| `shiftlens/evaluate.py` | Aggregate view scores by maximum, calibrate on known-good parts, and measure held-out recall, false rejects, average precision and AUROC. |
| `shiftlens/report.py` | Export an offline results viewer with actual model scores for synthetic examples. |

## Benchmark limits

The optional Real-IAD experiment uses scikit-learn on CPU and downsamples images to 256 px. The patch maps have 8 px resolution at the model input. Thresholds use an empirical calibration budget. The actual false-reject rate can be higher on held-out parts. Small calibration samples limit the effective rate resolution. The current adapter is based on the documented metadata and has been tested against a simulated Real-IAD directory. Real-IAD training requires the gated dataset files. VisA supports GPU execution with an appropriate PyTorch build. Neither benchmark establishes performance on a specific factory line.
