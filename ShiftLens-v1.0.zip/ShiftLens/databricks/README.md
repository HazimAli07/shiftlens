# ShiftLens on Databricks

Import [ShiftLens_Benchmark.ipynb](ShiftLens_Benchmark.ipynb) in a Databricks workspace and run it on serverless compute. The notebook embeds the actual VisA release metrics and needs no image archive. Set a writable catalog in the notebook controls if your workspace's current catalog is read-only.

The notebook checks the 36 metric rows, creates a Delta table keyed by snapshot × detector × category, and exposes a summary view with recall, false rejects per 1,000, and macro AUROC. Rerunning an unchanged snapshot leaves the row count unchanged.

For a Databricks workspace where the CLI is authenticated, the repository's `databricks.yml` defines a deployable job. Run `databricks bundle validate`, then `databricks bundle deploy` and `databricks bundle run shiftlens_benchmark`. These operations require a writable workspace. The public browser app runs independently of Databricks.
