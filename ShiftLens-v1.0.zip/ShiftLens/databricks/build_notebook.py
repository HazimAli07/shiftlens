"""Create a self-contained Databricks notebook from the released benchmark."""

import argparse
import hashlib
import json
from pathlib import Path

METRICS = (
    "true_rejects", "false_rejects", "defective_test_parts", "normal_test_parts",
    "auroc", "average_precision", "threshold",
)


def bench_rows(report):
    expected = {"Convolutional detector", "Reference template", "Patch retrieval"}
    rows = []
    seen = set()
    for category in report["categories"]:
        name = category["category"]
        if name in seen or set(category["metrics"]) != expected:
            raise ValueError(f"Incomplete or repeated model coverage in {name}")
        seen.add(name)
        for model, data in category["metrics"].items():
            row = {key: data[key] for key in METRICS}
            tp, fp, positives, negatives = (row[key] for key in METRICS[:4])
            if not (positives > 0 and negatives > 0 and 0 <= tp <= positives and 0 <= fp <= negatives
                    and positives + negatives == category["test"]
                    and 0 <= row["auroc"] <= 1 and 0 <= row["average_precision"] <= 1):
                raise ValueError(f"Invalid metric row at {name}/{model}")
            rows.append({"category": name, "detector": model, **row})
    if len(rows) != 36 or sum(category["test"] for category in report["categories"]) != 2162:
        raise ValueError("The release must cover all 12 categories and all held-out images.")
    return sorted(rows, key=lambda row: (row["category"], row["detector"]))


def markdown(body):
    return {"cell_type": "markdown", "metadata": {}, "source": body.splitlines(keepends=True)}


def code(body):
    return {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [],
            "source": body.splitlines(keepends=True)}


def build(report_path, output):
    report = json.loads(report_path.read_text())
    payload = json.dumps(bench_rows(report), separators=(",", ":"), allow_nan=False)
    run_id = "visa-" + hashlib.sha256(payload.encode()).hexdigest()[:16]
    validate = r'''
import json
import math
import re

dbutils.widgets.text("catalog", "", "Catalog (blank uses current)")
dbutils.widgets.text("schema", "shiftlens_portfolio", "Schema")
catalog = dbutils.widgets.get("catalog").strip() or spark.sql("SELECT current_catalog()").first()[0]
schema = dbutils.widgets.get("schema").strip()
for value in (catalog, schema):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise ValueError("Choose a catalog and schema with simple SQL identifiers.")
namespace = f"`{catalog}`.`{schema}`"
parsed = json.loads(PAYLOAD)
identity = {(row["category"], row["detector"]) for row in parsed}
if len(parsed) != 36 or len(identity) != 36:
    raise ValueError("Expected one row per detector and 12 categories.")
for row in parsed:
    if not all(math.isfinite(row[x]) for x in ("auroc", "average_precision", "threshold")):
        raise ValueError("Non-finite metrics")
    if not 0 <= row["true_rejects"] <= row["defective_test_parts"]:
        raise ValueError("Invalid positive test counts")
    if not 0 <= row["false_rejects"] <= row["normal_test_parts"]:
        raise ValueError("Invalid negative test counts")
df = spark.createDataFrame([dict(row, run_id=RUN_ID, split_sha256=SPLIT_SHA256) for row in parsed])
df.createOrReplaceTempView("shiftlens_release_incoming")
'''
    ingest = r'''
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {namespace}")
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {namespace}.benchmark_results (
  run_id STRING, split_sha256 STRING, category STRING, detector STRING, true_rejects BIGINT,
  false_rejects BIGINT, defective_test_parts BIGINT, normal_test_parts BIGINT,
  auroc DOUBLE, average_precision DOUBLE, threshold DOUBLE
) USING DELTA
""")
spark.sql(f"""
MERGE INTO {namespace}.benchmark_results AS target
USING shiftlens_release_incoming AS source
ON target.run_id = source.run_id AND target.category = source.category AND target.detector = source.detector
WHEN NOT MATCHED THEN INSERT *
""")
stored = spark.sql(f"SELECT * FROM {namespace}.benchmark_results").where(df.run_id == RUN_ID)
assert stored.count() == 36, "Incomplete or duplicate benchmark snapshot"
'''
    ingest = ingest.replace('.where(df.run_id == RUN_ID)', '.where(f"run_id = \'{RUN_ID}\'")')
    aggregate = r'''
spark.sql(f"""
CREATE OR REPLACE VIEW {namespace}.benchmark_summary AS
SELECT run_id, detector, COUNT(*) AS categories,
       SUM(true_rejects) AS defects_caught, SUM(defective_test_parts) AS defective_images,
       SUM(false_rejects) AS good_images_flagged, SUM(normal_test_parts) AS good_images,
       ROUND(SUM(true_rejects) / SUM(defective_test_parts), 4) AS recall,
       ROUND(1000.0 * SUM(false_rejects) / SUM(normal_test_parts), 1) AS false_rejects_per_1000,
       ROUND(AVG(auroc), 3) AS macro_auroc
FROM {namespace}.benchmark_results
GROUP BY run_id, detector
""")
display(spark.sql(f"SELECT * FROM {namespace}.benchmark_summary WHERE run_id = '{RUN_ID}' ORDER BY macro_auroc DESC"))
display(spark.sql(f"""
  SELECT category, detector, true_rejects AS defects_caught,
         false_rejects AS good_images_flagged, ROUND(auroc, 3) AS auroc
  FROM {namespace}.benchmark_results WHERE run_id = '{RUN_ID}'
  ORDER BY category, auroc DESC
"""))
'''
    notebook = {"cells": [
        markdown("# ShiftLens evaluation on Databricks\n\nValidate 36 benchmark rows, append a content-addressed snapshot to Delta, and query recall and false rejects. The notebook embeds released aggregate metrics and runs without image files or an external download. Select a catalog where you can create a schema before running it."),
        code(f"RUN_ID = {run_id!r}\nSPLIT_SHA256 = {report['manifest_sha256']!r}\nPAYLOAD = {payload!r}\n"),
        markdown("## Validate the published benchmark\n\nEach row represents one detector and object category. The full snapshot covers 2,162 held-out images with three independent scores per image."),
        code(validate),
        markdown("## Persist the snapshot\n\nThe merge key is run, category, and detector. Rerunning the same snapshot keeps 36 rows."),
        code(ingest),
        markdown("## Read the operating trade-offs\n\nRecall is pooled across held-out images. AUROC is a simple average across categories."),
        code(aggregate),
    ], "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python"},
    }, "nbformat": 4, "nbformat_minor": 4}
    for cell in notebook["cells"]:
        if cell["cell_type"] == "code":
            compile("".join(cell["source"]), output.name, "exec")
    output.write_text(json.dumps(notebook, indent=2, allow_nan=False) + "\n")
    print(run_id, len(bench_rows(report)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    build(args.report, args.output)
