# ShiftLens LinkedIn launch

I built ShiftLens to answer a practical question in industrial inspection: how many defects can a model catch before it starts flagging too many good parts?

ShiftLens lets you inspect images locally in Chrome, compare two detectors, view heatmaps, and export the results. I benchmarked three methods across 12 VisA categories using 2,162 held-out images.

The best result came from patch retrieval. It caught 442 of 1,200 defects and flagged 63 of 962 good images. The CNN caught 122 defects and flagged 55 good images. Keeping the reference methods in the benchmark made that trade-off impossible to miss.

The project includes a PyTorch pipeline, browser score checks against Python, and a Databricks notebook for validating the benchmark and querying it in Delta.

Try ShiftLens: https://hazimali07.github.io/shiftlens/
Code and benchmark: https://github.com/HazimAli07/shiftlens

#ComputerVision #MachineLearning #SoftwareEngineering #Databricks
